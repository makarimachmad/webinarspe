package config

import (
	"fmt"
	"os"

	"github.com/joho/godotenv"
)

func Config(key string) string {
	err := godotenv.Load(".env")
	if err != nil{
		fmt.Println("gagal ambil nilai di dalam env")
	}
	return os.Getenv(key)
}