package user

import "github.com/gofiber/fiber/v2"

func UserGet(c *fiber.Ctx) error{
	user := new(Users)
	err := user.GetUsers()
	if err != nil{
		return c.Status(404).JSON(fiber.Map{"status":"not found", "message":"data pengguna tidak ada", "data":nil})
	}
	return c.Status(200).JSON(fiber.Map{"status":"berhasil", "message":"data user ditemukan", "data":user})
}

func UserPost(c *fiber.Ctx) error{
	user := new(User)
	err := c.BodyParser(user)
	if err != nil{
		return c.Status(500).JSON(fiber.Map{"status":"internal server error", "message":"cek kembali data yg dimasukkan", "data":nil})
	}
	err = user.PostUser()
	if err != nil{
		return c.Status(500).JSON(fiber.Map{"status":"internal server error", "message":"gagal menambahkan ke database", "data":nil})
	}
	return c.Status(200).JSON(fiber.Map{"status":"berhasil", "message":"berhasil menambahkan data", "data":user})
}

func UserUpdate(c *fiber.Ctx) error{
	user := new(User)
	err := c.BodyParser(user)
	if err != nil{
		return c.Status(500).JSON(fiber.Map{"status":"internal server error", "message":"cek kembali nilai yang dimasukkan", "data":nil})
	}
	id := c.Params("idx")
	err = user.UpdateUser(id)
	if err != nil{
		return c.Status(500).JSON(fiber.Map{"status":"internal server error", "message":"gagal masuk ke dalam database", "data":nil})
	}
	return c.Status(200).JSON(fiber.Map{"status":"berhasil", "message":"berhasil merubah data","data":user})
}

func UserDelete(c *fiber.Ctx) error{
	user := new(User)
	id := c.Params("idx")
	err := user.DeleteUser(id)
	if err != nil{
		return c.Status(500).JSON(fiber.Map{"status":"internal server error", "message":"cek kembali id", "data":nil})
	}
	return c.Status(200).JSON(fiber.Map{"status":"berhasil", "message":"berhasil menghapus data"})
}